import sys

print("jsschaf"+"\x00"*3 + "A+");
